
WHAT THIS MODULE CONTAINS?
--------------------------------

This module is used to extend the site settings form of drupal core and add the 
additional functionalities in it.

Also this module contains a rest get resource plugin to fetch the respective node
details based on the site api key.

ORGANIZING MODULES IN THIS DIRECTORY
------------------------------------

The modules in this directory are organized into two subsections of src that is,
Form and Plugin.

MORE INFORMATION
----------------

While developing this module,information and development guide is referred through
drupal.org and other internet sources.

Time taken to develop this module is approximately 1 working day.